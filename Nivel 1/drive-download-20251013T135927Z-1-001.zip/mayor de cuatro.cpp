#include <iostream>
#include <conio.h>
using namespace std;

int main() {    //Hecho por George Fernando Pelaez Carrera 10MO A

    double numero[3];

    cout << "ingrese los tres numeros" << endl;
    for (int i=0;i<=3;i++) {
        cin >> numero[i];
    }

    if (numero[0]>numero[1] && numero[0]>numero[2] && numero[0]>numero[3]) {
        cout << "el numero: " << numero[0] << " es el mayor de los cuatro" << endl;
    } else if (numero[1]>numero[0] && numero[1]>numero[2] && numero[1]>numero[3]) {
        cout << "el numero: " << numero[1] << " es el mayor de los cuatro" << endl;
    } else if (numero[2]>numero[0] && numero[2]>numero[1] && numero[2]>numero[3]){
        cout << "el numero: " << numero[2] << " es el mayor de los cuatro" << endl;
    } else {
        cout << "el numero: " << numero[3] << " es el mayor de los cuatro" << endl;
    }
    
    getch();
    return 0;
}