#include <iostream>
#include <conio.h>
#include <string.h>

using namespace std;

int main() {    //Hecho por George Fernando Pelaez Carrera 10MO A
    char palabra[29];
    char comparativa[29];

    cout << "ingresa la palabra" << endl;

    cin.getline(palabra,29,'\n');

    strcpy(comparativa,palabra);

    strupr(comparativa);

    if (strcmp(palabra,comparativa)==0) {
        cout << "la palabra esta en mayusculas" << endl;
    } else if (palabra[0] == comparativa[0] && strcmp(palabra,comparativa)!=0) {
        cout << "minuscula" << endl;
        cout << "la primera letra no cuenta" << endl;
    } else {
        cout << "esta en minuscula" << endl;
    }
    getch();
    return 0;
}