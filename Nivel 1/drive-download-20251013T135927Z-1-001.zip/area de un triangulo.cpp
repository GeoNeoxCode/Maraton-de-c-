#include <iostream>
#include <conio.h>
using namespace std;

int main() {    //Hecho por George Fernando Pelaez Carrera 10MO A
    double base;
    double altura;
    double area;

    cout << "ingrese la altura del triangulo" << endl;
    cin >> altura;
    cout << "ingrese la base del triangulo" << endl;
    cin >> base;

    area = (base*altura)/2;

    cout << "el area del triangulo es de: " << area << endl;
    getch();
    return 0;
}