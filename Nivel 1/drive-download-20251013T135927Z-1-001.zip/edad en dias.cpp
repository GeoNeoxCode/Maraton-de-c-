#include <iostream>
#include <conio.h>
using namespace std;

int main() {    //Hecho por George Fernando Pelaez Carrera
    int edad;
    int dias;

    cout << "ingresa tu edad" << endl;
    cin >> edad;
    dias = edad*365;

    cout << "tu edad en dias es de: " << dias << " dias" << endl;

    getch();
    return 0;
}