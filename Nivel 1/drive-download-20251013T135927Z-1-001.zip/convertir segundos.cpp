#include <iostream>
#include <conio.h>
#include <iomanip>
using namespace std;
int main() {    //Hecho por George Fernando Pelaez Carrera 10MO A
    int segundos;
    float minutos;
    float horas;
    float dias;

    cout << "ingresa la cantidad de segundos"<< endl;
    cin >> segundos;

    while (segundos<0) {
        cout << "no se puede operar con ese valor" << endl;
        cin >> segundos;
    }

    minutos = segundos/60;
    horas = minutos/60;
    dias = horas/24;

    cout << segundos << " segundo/s equivale a " << fixed << setprecision(2) << minutos << " minutos, " << horas << " horas, " << dias << " dias" << endl;
    getch();
    return 0;
}