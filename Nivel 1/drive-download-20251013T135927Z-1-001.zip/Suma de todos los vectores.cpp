#include <iostream>
#include <conio.h>
using namespace std;


int main() {    //Hecho por George Fernando Pelaez Carrera 10MOA 

    int i,cantidad,valor,sumatoria;
    sumatoria = 0;

    cout << "ingrese la cantidad de vectores que va a usar"<< endl;
    cin >> cantidad;

    int vector[cantidad];

    for (i=0; i<cantidad; i++) {
        cout << "ingrese el valor de vector "<< i+1 << endl;
        cin >> valor;
        vector[i] = valor;
    }

    for (i=0; i<cantidad; i++) {
        sumatoria += vector[i];
    }

    cout << "La sumatoria de todos los valores es: " << sumatoria << endl;
    getch();
    return 0;
}