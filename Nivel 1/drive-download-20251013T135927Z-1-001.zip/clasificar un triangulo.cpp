#include <iostream>
#include <conio.h>
using namespace std;
int main () {   //Hecho por George Fernando Pelaez Carrera 10MO A
    double lados[2];

    for (int i=0; i<=2;i++) {
        cout << "ingresa el valor del lado " << i+1 << endl;
        cin >> lados[i];

        while (lados[i]<0) {
            cout << "no se puede usar ese valor" << endl;
            cin >> lados[i];
        }
    }

    if (lados[0]==lados[1] && lados[1]==lados[2]) {
        cout << "es un triangulo isoceles" << endl;
    } else if (lados[0]==lados[1] || lados[0]==lados[2] || lados[1]==lados[0] || lados[1]==lados[2] || lados[2]==lados[0] || lados[2]==lados[1]) {
        cout << "es equilatero" << endl;
    } else {
        cout << "es escaleno" << endl;
    }

    getch();
    return 0;
}