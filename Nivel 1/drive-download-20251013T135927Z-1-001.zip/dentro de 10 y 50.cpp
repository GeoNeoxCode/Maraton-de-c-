#include <iostream>
#include <conio.h>
using namespace std;

int main() {    //Hecho por George Fernando Pelaez Carrera 10MO A
    int numero;

    cout << "ingresa el numero" << endl;
    cin >> numero;

    if (numero>=10 && numero<=50) {
        cout << "si pertenece" << endl;
    }

    getch();
    return 0;
}