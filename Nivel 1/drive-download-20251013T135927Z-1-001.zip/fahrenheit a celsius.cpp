#include <iostream>
#include <conio.h>
#include <iomanip>
using namespace std;

int main() {    //Hecho por George Fernando Pelaez Carrera 10MO A
    float celsius;
    float fahrenheit;
    cout << " ingresa los grados fahrenheit" << endl;
    cin >> fahrenheit;
    
    if (fahrenheit>32) {
        for (float i= 32; i<=fahrenheit;i+=1.8) {
            celsius++;
        }
    } else if (fahrenheit<32) {
      for (float i= 32; i>=fahrenheit;i-=1.8
    ) {
            celsius--;
        }  
    }

    cout << fahrenheit << " grados fahrenheits a celsius son: " << fixed << setprecision(1) << celsius << " celsius" << endl;

    getch();
    return 0;
}