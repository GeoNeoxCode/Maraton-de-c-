#include <iostream>
#include <conio.h>
using namespace std;


int main() {    //Hecho por George Fernando Pelaez Carrera
    float calificacion;
    int cantidad;
    float promedio;

    cout << "\tingresa tu cantidad de notas"<< endl;
    cin >> cantidad; 
    double notas[cantidad];

    cout << "\n\tahora ingresa la califaciones de tus notas" << endl;
    for (int i=0; i <=cantidad-1; i++) {
        cout << "\n\t\tingresa la califacion " << i+1 << endl;
        cin >> calificacion;
        while (calificacion<0 || calificacion>10) {
            cout << "\tesa no es una calificacion validad, vuela a intentarlo" << endl;
            cout << "\tla calificacion debe estar en un rango de 0 a 10"<< endl;
            cin >> calificacion;
        }

        notas[i]=calificacion;
    }

    for (int i=0; i<= cantidad; i++ ) {
        promedio =(promedio + notas[i]);
    }
    promedio =(promedio/cantidad);

    cout << "\n\t\ttu promedio es: " << promedio << endl;

    getch();

    return 0;
}