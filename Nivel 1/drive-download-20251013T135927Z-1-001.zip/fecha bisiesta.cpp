#include <iostream>
#include <conio.h>
using namespace std;

int main() {    //Hecho por George Fernando Pelaez Carrera 10MO A
    int year;

    cout << "ingresa el año" << endl;
    cin >> year;

    if (year%4==0) {
        cout <<"es un bisiesto" << endl;
    } else {
        cout <<"no es bisiesto" << endl;
    }


    getch();
    return 0;
}