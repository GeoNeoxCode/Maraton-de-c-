#include <iostream>
#include <conio.h>
using namespace std;

int main() {    //Hecho por George Fernando Pelaez Carrera 10MO A
    double producto;
    int descuento;
    double valor;
    cout << "Ingrese el precio del producto" << endl;
    cin >> producto;
    cout << "ingrese el porcentaje de descuento" << endl;
    cin >> descuento;
    while(descuento<0 || descuento>100) {
        cout << "no se acepta ese porcentaje" << endl;
        cin >> descuento;
    }

    valor = producto-((producto*descuento)/100);
    
    cout << "el valor del producto con un descuento del " << descuento << "%" << " es de: " << valor << "$"<< endl;
    getch();
    return 0;
}