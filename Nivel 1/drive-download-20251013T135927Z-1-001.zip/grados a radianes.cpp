#include <iostream>
#include <conio.h>
#include <iomanip>
using namespace std;

int main() {    //Hecho por George Fernando Pelaez Carrera 10MO A
    float grados;
    float radianes;

    cout << "ingrese los grados" << endl;
    cin >> grados;

    radianes = grados*0.01745329;

    cout << grados << " grados a radianes es: " << fixed << setprecision(4)<< radianes << " radianes" << endl;

    getch();
    return 0;
}