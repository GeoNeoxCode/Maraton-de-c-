#include <iostream>
#include <conio.h>
#include <string.h>
using namespace std;
int main() {    //Hecho por George Fernando Pelaez Carrera 10MO A
    char entrada[1];
    cout << "ingrese el caracter" << endl;
    cin.getline(entrada,2,'\n');

    strlwr(entrada);

    switch (entrada[0]) {
    case 'a':
        cout << "es una vocal" << endl;
        break;
    case 'e':
        cout << "es una vocal" << endl;
        break;
    case 'i':
        cout << "es una vocal" << endl;
        break;
    case 'o':
        cout << "es una vocal" << endl;
        break;
    case 'u':
        cout << "es una vocal" << endl;
        break;
    default:
        cout << "es una consonante" << endl;
        break;
    }
    getch();
    return 0;
}