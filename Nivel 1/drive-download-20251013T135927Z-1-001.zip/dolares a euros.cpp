#include <iostream>
#include <conio.h>
#include <iomanip>
using namespace std;

int main() {    //Hecho por George Fernando Pelaez Carrera 10MO A
    double dolar;
    double euros;
    cout << "ingrese la cantidad de dolares" << endl;
    cin >> dolar;
    while (dolar<0) {
        cout << "no se puede operar con esa cantidad" << endl;
        cin >> dolar;
    }

    euros = dolar*0.86;
    cout << dolar << "$ en euros es: " << euros << "€" << endl;
    getch();
    return 0;
}