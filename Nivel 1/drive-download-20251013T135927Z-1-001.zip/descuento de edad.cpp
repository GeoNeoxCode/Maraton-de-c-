#include <iostream>
#include <conio.h>
using namespace std;    //Hecho por George Fernando Pelaez Carrera 10MO A
int main() {
    double producto;
    int edad;

    cout << "ingresa tu edad" << endl;
    cin >> edad;

    while (edad<0) {
        cout << "esa no es una edad valida" << endl;
        cin >> edad;
    }
    cout << "ingresa el valor del producto" << endl;
    cin >> producto;
    while (producto<0) {
        cout << "ese no es un precio admitido" << endl;
        cin >> producto;
    }
    if (edad<18) {
        producto = producto-(producto*0.25);
        cout << "el valor del producto tiene un descuento por tu edad, el nuevo precio es de: " << producto << endl;
    } else if (edad>=64) {
        producto = producto - (producto*0.50);
        cout << "el valor del producto tiene un descuento por tu edad, el nuevo precio es de: " << producto << endl;
    } else {
        cout << "tu edad no tiene algun descuento" << endl;
    }


    getch();
    return 0;
}