#include <iostream>
#include <conio.h>
using namespace std;

int main() {    //Hecho por George Fernando Pelaez Carrera 10MO A
    float centimetros;
    float metros;

    cout << "ingrese el valor" << endl;
    cin >> centimetros;
    metros = centimetros/100;
    cout << " centimetros a metros es: " << metros << endl;

    getch();
    return 0;
}