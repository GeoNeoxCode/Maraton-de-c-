#include <iostream>
#include <conio.h>
using namespace std;

int main() {    //Hecho por George Fernando Pelaez Carrera 10MO A
    int entrada;

    cout << "ingresa el numero" << endl;
    cin >> entrada;

    if (entrada%3==0 && entrada%5==0) {
        cout << "si es multiplo de 3 y 5" << endl;
    
    } else {
        cout << "no es multiplo de ambos numeros" << endl;
    }
    getch();
    return 0;
}