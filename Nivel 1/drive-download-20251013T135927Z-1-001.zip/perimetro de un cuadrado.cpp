#include <iostream>
#include <conio.h>
using namespace std;

int main() {    //Hecho por George Fernando Pelaez Carrera 10MO A
    double lado;
    double perimetro;

    for(int i=0; i<4; i++) {
        cout << "ingrese los lados del cuadrado" << endl;
        cin >> lado;

        while(lado<0) {
            cout <<"no se acepta este valor" << endl;
            cin >> lado;
        }
        perimetro += lado;
    }

    cout << "el perimetro del cuadrado es de: " << perimetro << endl;

    getch();
    return 0;
}